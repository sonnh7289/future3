//
//  StickerCell.swift
//  FakeLocationV3
//
//  Created by Đỗ Việt on 17/04/2023.
//

import UIKit

class StickerCell: UICollectionViewCell {
    
    @IBOutlet weak var stickerImg: UIImageView!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
