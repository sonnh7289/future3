//
//  EditVC.swift
//  FakeLocationV3
//
//  Created by Đỗ Việt on 08/04/2023.
//

import UIKit
import Kingfisher
import StickerView

class EditVC: UIViewController {
    
    @IBOutlet weak var bgimageView: UIImageView!
    @IBOutlet weak var bgView: UIView!
    @IBOutlet weak var stickerCLV:UICollectionView!
    @IBOutlet weak var removeBgButton: UIButton!
    @IBOutlet weak var addImageView: UIButton!
    
    var listSticker = [CelebModel]()
    
    var picfromlib = false
    
    var bgImage = UIImage()
    
    var bgRemover = RemoveBackground()
    var imageView: UIImageView!
    var mainStickerView: StickerView!
    var inputImage = UIImage()
    
    private var _selectedStickerView:StickerView?
    
    var selectedStickerView:StickerView? {
        get {
            return _selectedStickerView
        }
        set {
            // if other sticker choosed then resign the handler
            if _selectedStickerView != newValue {
                if let selectedStickerView = _selectedStickerView {
                    selectedStickerView.showEditingHandlers = false
                }
                _selectedStickerView = newValue
            }
            // assign handler to new sticker added
            if let selectedStickerView = _selectedStickerView {
                selectedStickerView.showEditingHandlers = true
                selectedStickerView.superview?.bringSubviewToFront(selectedStickerView)
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        fetchData()
        stickerCLV.register(UINib(nibName: "StickerCell", bundle: nil), forCellWithReuseIdentifier: "StickerCell")
        bgImage = ResizeImage(with: bgImage, scaledToFill: bgimageView.frame.size)!
        bgimageView.image = bgImage
        
        if picfromlib == true {
            imageView = UIImageView.init(frame: CGRect.init(x: 0, y: 0, width: 200, height: 200))
            imageView.image = inputImage
            imageView.contentMode = .scaleAspectFit
            mainStickerView = StickerView.init(contentView: imageView)
            mainStickerView.center = CGPoint.init(x: 150, y: 150)
            mainStickerView.delegate = self
            mainStickerView.setImage(UIImage.init(named: "Close")!, forHandler: StickerViewHandler.close)
            mainStickerView.setImage(UIImage.init(named: "Rotate 1")!, forHandler: StickerViewHandler.rotate)
            mainStickerView.setImage(UIImage.init(named: "Flip")!, forHandler: StickerViewHandler.flip)
            mainStickerView.showEditingHandlers = false
            mainStickerView.tag = 999
            self.bgView.addSubview(mainStickerView)
            self.selectedStickerView = mainStickerView
        }
        else{
            removeBgButton.isHidden = true
            addImageView.isHidden = true
        }
    }
    
    private func fetchData(){
        APIService.shared.getAll(closure: { [self]
            response,error in
            if let listData = response {
                listSticker = listData
                DispatchQueue.main.async {
                    self.stickerCLV.reloadData()
                }
            }
            
        })
    }
    
    @IBAction func onTapClose(_ sender: UIButton){
        self.dismiss(animated: true)
    }
    
    @IBAction func onTapDone(_ sender: UIButton){
        
        selectedStickerView?.showEditingHandlers = false
        if self.bgimageView.subviews.filter({$0.tag == 999}).count >= 0 {
            if let imageCombine = mergeImages(imageView: bgimageView){
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                let vc = storyboard.instantiateViewController(withIdentifier: "DoneVC") as! DoneVC
                vc.modalPresentationStyle = .fullScreen
                vc.image = imageCombine
                self.present(vc, animated: true, completion: nil)
            }else{
                print("Image not found !!")
            }
        }else{
            print("Ko co anh")
        }

        
    }
    
    @IBAction func onTapDeleteBackground(_ sender: UIButton){
        bgRemover.inputImage = imageView.image!
        bgRemover.segmentImage()
        DispatchQueue.main.asyncAfter(deadline: .now() + 1){ [self] in
            imageView.image = bgRemover.outputImage

        }
    }
    
    func mergeImages(imageView: UIImageView) -> UIImage? {
        UIGraphicsBeginImageContextWithOptions(imageView.frame.size, false, 0.0)
        imageView.superview!.layer.render(in: UIGraphicsGetCurrentContext()!)
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return image
    }
    
    @IBAction func onTapAddBackground(_ sender: UIButton){
        
    }
    
//    @IBAction func nextRotate() {
//        bgimageView.transform = bgimageView.transform.rotated(by: CGFloat(M_PI_2))
//    }
//
//    @IBAction func preRotate() {
//        bgimageView.transform = bgimageView.transform.rotated(by: -CGFloat(M_PI_2))
//    }
}

extension EditVC : StickerViewDelegate {
    func stickerViewDidTap(_ stickerView: StickerView) {
        self.selectedStickerView = stickerView
    }
    
    func stickerViewDidBeginMoving(_ stickerView: StickerView) {
        self.selectedStickerView = stickerView
    }
    
    func stickerViewDidChangeMoving(_ stickerView: StickerView) {
        
    }
    
    func stickerViewDidEndMoving(_ stickerView: StickerView) {
        
    }
    
    func stickerViewDidBeginRotating(_ stickerView: StickerView) {
        
    }
    
    func stickerViewDidChangeRotating(_ stickerView: StickerView) {
        
    }
    
    func stickerViewDidEndRotating(_ stickerView: StickerView) {
        
    }
    
    func stickerViewDidClose(_ stickerView: StickerView) {
        
    }
}

extension EditVC : UICollectionViewDelegate, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return listSticker.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let object = listSticker[indexPath.row]
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "StickerCell", for: indexPath) as! StickerCell
        cell.stickerImg.kf.setImage(with: URL(string: object.linkanh))
        cell.layer.cornerRadius = 3
        cell.backgroundColor = .gray
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if let cell = collectionView.cellForItem(at: indexPath) as? StickerCell{
            if let imageSticker = cell.stickerImg.image {
                let testImage = UIImageView.init(frame: CGRect.init(x: 0, y: 0, width: 100, height: 100))
                testImage.image = imageSticker
                testImage.contentMode = .scaleAspectFit
                let stickerView3 = StickerView.init(contentView: testImage)
                stickerView3.center = CGPoint.init(x: 150, y: 150)
                stickerView3.delegate = self
                stickerView3.setImage(UIImage.init(named: "Close")!, forHandler: StickerViewHandler.close)
                stickerView3.setImage(UIImage.init(named: "Rotate 1")!, forHandler: StickerViewHandler.rotate)
                stickerView3.setImage(UIImage.init(named: "Flip")!, forHandler: StickerViewHandler.flip)
                stickerView3.showEditingHandlers = false
                stickerView3.tag = 999
                self.bgView.addSubview(stickerView3)
                self.selectedStickerView = stickerView3
            }else{
                print("Sticker not loaded")
            }
        }
    }
}

extension EditVC : UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 10
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 10
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 110, height: 110)
    }
}
