//
//  File.swift
//  FakeLocationV3
//
//  Created by Đỗ Việt on 14/04/2023.
//

import Foundation

class PlaceModel: NSObject {
    var categories: String = ""
    var link_img: String = ""
    var location: String = ""
    
    func initLoad(_ json:  [String: Any]) -> PlaceModel{
        if let temp = json["categories"] as? String { categories = temp}
        if let temp = json["link-img"] as? String { link_img = temp}
        if let temp = json["location"] as? String { location = temp}
        return self
    }
}
