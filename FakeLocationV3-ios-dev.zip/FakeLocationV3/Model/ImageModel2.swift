//
//  ImageModel2.swift
//  FakeLocationV3
//
//  Created by Đỗ Việt on 09/05/2023.
//

import Foundation

import UIKit
class ImgModel2: NSObject{
    var link = ""
    func initLoad(_ json:  String) -> ImgModel2{
        link = json
        return self
    }
    
}
