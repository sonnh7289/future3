//
//  k.swift
//  FakeLocationV3
//
//  Created by Đỗ Việt on 27/04/2023.
//

import CoreGraphics
import UIKit

public func ResizeImage(with image: UIImage?, scaledToFill size: CGSize) -> UIImage? {
    let scale: CGFloat = max(size.width / (image?.size.width ?? 0.0), size.height / (image?.size.height ?? 0.0))
    let width: CGFloat = (image?.size.width ?? 0.0) * scale
    let height: CGFloat = (image?.size.height ?? 0.0) * scale
    let imageRect = CGRect(x: (size.width - width) / 2.0, y: (size.height - height) / 2.0, width: width, height: height)
    UIGraphicsBeginImageContextWithOptions(size, false, 0)
    image?.draw(in: imageRect)
    let newImage: UIImage? = UIGraphicsGetImageFromCurrentImageContext()
    UIGraphicsEndImageContext()
    return newImage
}

extension UIImage {
    static func gradientImage(bounds: CGRect, colors: [UIColor]) -> UIImage {
        let gradientLayer = CAGradientLayer()
        gradientLayer.frame = bounds
        gradientLayer.colors = colors.map(\.cgColor)
        // This makes it left to right, default is top to bottom
        gradientLayer.startPoint = CGPoint(x: 0.0, y: 0.5)
        gradientLayer.endPoint = CGPoint(x: 1.0, y: 0.5)

        let renderer = UIGraphicsImageRenderer(bounds: bounds)

        return renderer.image { ctx in
            gradientLayer.render(in: ctx.cgContext)
        }
    }
}

