//
//  ViewController2.swift
//  FakeLocationV3
//
//  Created by Đỗ Việt on 07/04/2023.
//

import UIKit
import Kingfisher

class ViewController2: UIViewController, UIImagePickerControllerDelegate & UINavigationControllerDelegate {
    
    var imagePicker = UIImagePickerController()
    @IBOutlet weak var imageView: UIImageView!
    var image = UIImage()
    
    let backButton : UIButton = {
        let button = UIButton()
        let image = UIImage(named: "left-arrow (1)")?.withRenderingMode(.alwaysTemplate)
        button.setImage(image, for: .normal)
        button.tintColor = .blue
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.addSubview(backButton)
        NSLayoutConstraint.activate([
            
            backButton.widthAnchor.constraint(equalToConstant: 50),
            backButton.heightAnchor.constraint(equalToConstant: 50),
            backButton.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 10),
            backButton.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 50),
        ])
        backButton.addTarget(self, action: #selector(back(_:)), for: .touchUpInside)
        
        imageView.image = image
       
    }
    
    @objc func back(_ sender: UIButton?){
        self.dismiss(animated: true)
    }
    
    @IBAction func onTapCamera(_ sender: UIButton) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "cameraVC") as! cameraVC
        vc.modalPresentationStyle = .fullScreen
        vc.background = image
        self.present(vc, animated: true, completion: nil)
    }
    
    @IBAction func onTapLirary(_ sender: UIButton) {
        if UIImagePickerController.isSourceTypeAvailable(.savedPhotosAlbum){
            print("Button capture")
            
            imagePicker.delegate = self
            imagePicker.sourceType = .savedPhotosAlbum
            imagePicker.allowsEditing = false
            
            present(imagePicker, animated: true, completion: nil)
        }
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        
        imagePicker.dismiss(animated: true, completion: nil)
        
        guard let image1 = info[.originalImage] as? UIImage else {
            fatalError("Expected a dictionary containing an image, but was provided the following: \(info)")
        }
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "EditVC") as! EditVC
        vc.modalPresentationStyle = .fullScreen
        vc.inputImage =  image1
        vc.picfromlib = true
        vc.bgImage = image
        self.present(vc, animated: true, completion: nil)
    }
    
    @IBAction func onTapBack(_ sender: UIButton) {
        self.dismiss(animated: true)
    }
    
}


