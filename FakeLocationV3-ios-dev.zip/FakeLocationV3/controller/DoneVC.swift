//
//  DoneVC.swift
//  FakeLocationV3
//
//  Created by Đỗ Việt on 09/04/2023.
//

import UIKit
import CoreLocation
import MapKit
import Photos
import JGProgressHUD

class DoneVC: UIViewController, CLLocationManagerDelegate {
    
    @IBOutlet weak var imageView: UIImageView!
    var image = UIImage()
    
    var latit: Double?
    var longit: Double?
    
    let locationManager = CLLocationManager()
    
    var hi:ImgModel = ImgModel()
    var hi2:ImgModel2 = ImgModel2()
    
    let hud = JGProgressHUD()
    
    func textToImage(drawText text: NSString, inImage image: UIImage) -> UIImage {
        UIGraphicsBeginImageContext(image.size)
        image.draw(in: CGRect(x: 0, y: 0, width: image.size.width, height: image.size.height))
        let font = UIFont(name: "Helvetica-Bold", size: 20)!
        let text_style = NSMutableParagraphStyle()
        text_style.alignment = NSTextAlignment.right
        let text_color=UIColor.white
        let attributes=[NSAttributedString.Key.font:font, NSAttributedString.Key.paragraphStyle:text_style, NSAttributedString.Key.foregroundColor:text_color]
        let text_h = font.lineHeight
        let text_y = (image.size.height-text_h) - 10
        let text_rect = CGRect(x: 0, y: text_y, width: image.size.width - 20, height: text_h)
        text.draw(in: text_rect.integral, withAttributes: attributes)
        let result = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return result!
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
        hud.show(in: view)
        let userImage:UIImage = image
        let imageData:NSData = userImage.pngData()! as NSData
        let dataImage = imageData.base64EncodedString(options: .lineLength64Characters)
        let sonaParam = ["image":dataImage]
        APIService.shared.PostImageServer(param: imageData as Data){data, error in
            if let data = data{
                self.hi = data
                print(self.hi.display_url)
                APIService.shared.GetData(self.hi.display_url){data, error in
                    if let data = data{
                        self.hi2 = data
                        print(self.hi2)
                        let dataDecoded : Data = Data(base64Encoded: self.hi2.link, options: .ignoreUnknownCharacters)!
                        let decodedimage = UIImage(data: dataDecoded)
                        self.imageView.image = self.textToImage(drawText: "This image changed background", inImage: decodedimage!)
                        self.hud.dismiss(animated: true)
                    }
                }
            }
        }
        
        // Ask for Authorisation from the User.
        self.locationManager.requestAlwaysAuthorization()

        // For use in foreground
        self.locationManager.requestWhenInUseAuthorization()
        
        latit = locationManager.location?.coordinate.latitude
        longit = locationManager.location?.coordinate.longitude

        if CLLocationManager.locationServicesEnabled() {
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
            locationManager.startUpdatingLocation()
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let locValue: CLLocationCoordinate2D = manager.location?.coordinate else { return }
    }
    
    func showMiracle() {
        let slideVC = OverlayView()
        slideVC.modalPresentationStyle = .custom
        slideVC.transitioningDelegate = self
        slideVC.latit = locationManager.location?.coordinate.latitude
        slideVC.longit = locationManager.location?.coordinate.longitude
        self.present(slideVC, animated: true, completion: nil)
        slideVC.callBack = { [self]
            x,y in
            if x != locationManager.location?.coordinate.latitude {
                latit = x
            }
            
            if y != locationManager.location?.coordinate.longitude {
                longit = y
            }
        }
    }
    
    @IBAction func onTapBack(){
        self.dismiss(animated: true)
    }
    
    @IBAction func onTapDone(){
        showAlertWith(title: "Saved!", message: "Your image will save to your photos.")
    }
    
    func convertImageToBase64String (img: UIImage) -> String {
        return img.jpegData(compressionQuality: 1)?.base64EncodedString() ?? ""
    }
    
    func showAlertWith(title: String, message: String){
        let ac = UIAlertController(title: title, message: message, preferredStyle: .alert)
        ac.addAction(UIAlertAction(title: "Continue Editing", style: .default){
            _ in
            self.dismiss(animated: true)
        })
        ac.addAction(UIAlertAction(title: "OK", style: .default){ [self]
            _ in
            
            let image:UIImage = imageView.image! // your UIImage

            // create filename
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyyy.MM.dd-HH.mm.ss"
            let now = Date()
            let date_time = dateFormatter.string(from: now)
            let fileName:String = "your_image_"+date_time+".jpg" // name your file the way you want
            let temporaryFolder:URL = FileManager.default.temporaryDirectory
            let temporaryFileURL:URL = temporaryFolder.appendingPathComponent(fileName)
            
            // save the image to chosen path
            let jpeg = image.jpegData(compressionQuality: 1.0)! // set JPG quality here (1.0 is best)
            let src = CGImageSourceCreateWithData(jpeg as CFData, nil)!
            let uti = CGImageSourceGetType(src)!
            let cfPath = CFURLCreateWithFileSystemPath(nil, temporaryFileURL.path as CFString, CFURLPathStyle.cfurlposixPathStyle, false)
            let dest = CGImageDestinationCreateWithURL(cfPath!, uti, 1, nil)

            // create GPS metadata from current location
            let gCurrentLocation = CLLocation(latitude: latit!, longitude: longit!)
            let gpsMeta = gCurrentLocation.exifMetadata() // gCurrentLocation is your CLLocation (exifMetadata is an extension)
            let tiffProperties = [
                kCGImagePropertyTIFFMake as String: "Camera vendor",
                kCGImagePropertyTIFFModel as String: "Camera model"
                // --(insert other properties here if required)--
            ] as CFDictionary

            let properties = [
                kCGImagePropertyTIFFDictionary as String: tiffProperties,
                kCGImagePropertyGPSDictionary: gpsMeta as Any
                // --(insert other dictionaries here if required)--
            ] as CFDictionary

            CGImageDestinationAddImageFromSource(dest!, src, 0, properties)
            if (CGImageDestinationFinalize(dest!)) {
                
                try? PHPhotoLibrary.shared().performChangesAndWait {
                    PHAssetChangeRequest.creationRequestForAssetFromImage(atFileURL: temporaryFileURL)
                }
                
                if FileManager.default.fileExists(atPath: temporaryFileURL.path) {
                    do {
                        try FileManager.default.removeItem(atPath: temporaryFileURL.path)
                        print("Delete Success")
                    } catch {
                        print("Could not delete file, probably read-only filesystem")
                    }
                }
            } else {
                print("Error saving image with metadata")
            }
            
            self.view.window?.rootViewController?.dismiss(animated: true, completion: nil) 
        })
        present(ac, animated: true)
    }
    
    @IBAction func onTap3Dot(){
        showMiracle()
    }
    
    
}

extension DoneVC: UIViewControllerTransitioningDelegate {
    func presentationController(forPresented presented: UIViewController, presenting: UIViewController?, source: UIViewController) -> UIPresentationController? {
        PresentationController(presentedViewController: presented, presenting: presenting)
    }
}

extension CLLocation {
    func exifMetadata(heading:CLHeading? = nil) -> NSMutableDictionary {
        let GPSMetadata = NSMutableDictionary()
        let altitudeRef = Int(self.altitude < 0.0 ? 1 : 0)
        let latitudeRef = self.coordinate.latitude < 0.0 ? "S" : "N"
        let longitudeRef = self.coordinate.longitude < 0.0 ? "W" : "E"

        // GPS metadata
        GPSMetadata[(kCGImagePropertyGPSLatitude as String)] = abs(self.coordinate.latitude)
        GPSMetadata[(kCGImagePropertyGPSLongitude as String)] = abs(self.coordinate.longitude)
        GPSMetadata[(kCGImagePropertyGPSLatitudeRef as String)] = latitudeRef
        GPSMetadata[(kCGImagePropertyGPSLongitudeRef as String)] = longitudeRef
        GPSMetadata[(kCGImagePropertyGPSAltitude as String)] = Int(abs(self.altitude))
        GPSMetadata[(kCGImagePropertyGPSAltitudeRef as String)] = altitudeRef
        GPSMetadata[(kCGImagePropertyGPSTimeStamp as String)] = self.timestamp.isoTime()
        GPSMetadata[(kCGImagePropertyGPSDateStamp as String)] = self.timestamp.isoDate()
        GPSMetadata[(kCGImagePropertyGPSVersion as String)] = "2.2.0.0"

        if let heading = heading {
            GPSMetadata[(kCGImagePropertyGPSImgDirection as String)] = heading.trueHeading
            GPSMetadata[(kCGImagePropertyGPSImgDirectionRef as String)] = "T"
        }

        return GPSMetadata
    }
}

extension Date {

    func isoDate() -> String {
        let f = DateFormatter()
        f.timeZone = TimeZone(abbreviation: "UTC")
        f.dateFormat = "yyyy:MM:dd"
        return f.string(from: self)
    }

    func isoTime() -> String {
        let f = DateFormatter()
        f.timeZone = TimeZone(abbreviation: "UTC")
        f.dateFormat = "HH:mm:ss.SSSSSS"
        return f.string(from: self)
    }
}

class ImageSaver: NSObject {
    func writeToPhotoAlbum(image: UIImage) {
        UIImageWriteToSavedPhotosAlbum(image, self, #selector(saveCompleted), nil)
    }

    @objc func saveCompleted(_ image: UIImage, didFinishSavingWithError error: Error?, contextInfo: UnsafeRawPointer) {
        print("Save finished!")
    }
}

