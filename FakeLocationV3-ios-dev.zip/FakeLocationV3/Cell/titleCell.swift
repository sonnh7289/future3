//
//  titleCell.swift
//  FakeLocationV3
//
//  Created by Đỗ Việt on 07/04/2023.
//

import UIKit

class titleCell: UICollectionViewCell {
    
    static let identifier = "titleCell"
    
    @IBOutlet weak var titleLb: UILabel!
    @IBOutlet weak var seemoreBut: UIButton!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    @IBAction func onTapSeeMore(_ sender: UIButton){
        
    }

}
