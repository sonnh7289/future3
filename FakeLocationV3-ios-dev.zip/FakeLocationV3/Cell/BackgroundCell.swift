//
//  BackgroundCell.swift
//  FakeLocationV3
//
//  Created by Đỗ Việt on 07/04/2023.
//

import UIKit

class BackgroundCell: UICollectionViewCell {
    
    static let identifier = "ListCell"
    
    @IBOutlet weak var backgroundImg: UIImageView!
    @IBOutlet weak var location: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
    }

}
