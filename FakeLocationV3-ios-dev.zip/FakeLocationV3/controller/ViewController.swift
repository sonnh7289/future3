//
//  ViewController.swift
//  FakeLocationV3
//
//  Created by Đỗ Việt on 06/04/2023.
//

import UIKit
import Kingfisher

class ViewController: UIViewController, UIImagePickerControllerDelegate & UINavigationControllerDelegate {
    
    @IBOutlet weak var mainCLV: UICollectionView!
    @IBOutlet weak var searchtf: UITextField!
    @IBOutlet weak var tagCLV: UICollectionView!
    
    @IBOutlet weak var countryView: UIView!
    @IBOutlet weak var landscapeView: UIView!
    @IBOutlet weak var peopleView: UIView!
    @IBOutlet weak var seasonView: UIView!
    
    var listPlace: [PlaceModel] = [PlaceModel]()
    var fillerArray = [PlaceModel]()
    var ListTag = ["All","Vietnam","Usa","Japan","Germany","France","China","Canada","Austria","Uk","Spain","Netherlands","Korea","Italy","Holland","Greece"]

    override func viewDidLoad() {
        super.viewDidLoad()
        mainCLV.register(UINib(nibName: "BackgroundCell", bundle: nil), forCellWithReuseIdentifier: "BackgroundCell")
        tagCLV.register(UINib(nibName: "tagCell", bundle: nil), forCellWithReuseIdentifier: "tagCell")
        fetchData()
        mainCLV.reloadData()
        
        countryView.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(country)))
        peopleView.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(people)))
        landscapeView.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(landscape)))
        seasonView.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(season)))
    }
    
    @objc func country(){
        fillerArray = listPlace
        mainCLV.reloadData()
        self.mainCLV.setContentOffset(CGPoint(x:0,y:0), animated: true)
    }
    
    @objc func people(){
        fillerArray = listPlace.filter{$0.categories == "people"}
        mainCLV.reloadData()
        self.mainCLV.setContentOffset(CGPoint(x:0,y:0), animated: true)
    }
    
    @objc func landscape(){
        fillerArray = listPlace.filter{$0.categories == "Landscape"}
        mainCLV.reloadData()
        self.mainCLV.setContentOffset(CGPoint(x:0,y:0), animated: true)
    }
    
    @objc func season(){
        fillerArray = listPlace.filter{$0.categories == "Season"}
        mainCLV.reloadData()
        self.mainCLV.setContentOffset(CGPoint(x:0,y:0), animated: true)
    }
    
    @IBAction func onTapUpLoad() {
        ImagePickerManager().pickImage(self){ image in
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: "ViewController2") as! ViewController2
            vc.modalPresentationStyle = .fullScreen
            vc.image = image
            self.present(vc, animated: true, completion: nil)
        }
    }
    
    func fetchData() {
        guard let path = Bundle.main.path(forResource: "location-data", ofType: "json") else{
            return
        }
        let url = URL(fileURLWithPath: path)
        
        do {
            let data = try Data(contentsOf: url)
            let json = try JSONSerialization.jsonObject(with: data,options: .mutableContainers)
            
            if let d = json as? [[String : Any]] {
                for i in d {
                    let item = PlaceModel()
                    item.initLoad(i)
                    listPlace.append(item)
                }
            }
            
        }catch{
            print(error)
        }
        fillerArray = listPlace
    }
}

extension ViewController : UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        if collectionView == tagCLV {
            return ListTag.count
        }
        
        return fillerArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if collectionView == tagCLV {
            let object = ListTag[indexPath.row]
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "tagCell", for: indexPath) as! tagCell
            cell.nameTagLb.text = "#\(object)"
            cell.layer.cornerRadius = 5
            cell.backgroundColor = UIColor(red: .random(in: 0...1), green: .random(in: 0...1), blue: .random(in: 0...1), alpha: 1.0)
            return cell
        }
        
        let object = fillerArray[indexPath.row]
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "BackgroundCell", for: indexPath) as! BackgroundCell
        cell.layer.cornerRadius = 16
        cell.backgroundImg.kf.setImage(with: URL(string: object.link_img))
        let gradient = UIImage.gradientImage(bounds: cell.location.bounds, colors: [.systemRed, .systemBlue])
        cell.location.textColor = UIColor(patternImage: gradient)
        cell.location.text = object.location
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        if collectionView == tagCLV {
            let object = ListTag[indexPath.row]
            
            if object == "All" {
                fillerArray = listPlace
                self.mainCLV.reloadData()
            }else{
                let first2 = object
                fillerArray = self.listPlace.filter({(($0.location).localizedCaseInsensitiveContains(first2))})
                self.mainCLV.reloadData();
            }
        }
        else{
            
            let cell = collectionView.cellForItem(at: indexPath) as! BackgroundCell
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: "ViewController2") as! ViewController2
            vc.modalPresentationStyle = .fullScreen
            vc.image = cell.backgroundImg.image!
            self.present(vc, animated: true, completion: nil)
        }
        
    }
}

extension ViewController : UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 5
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 5
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if collectionView == tagCLV {
            return CGSize(width: 100, height: 25)
        }
        
        return CGSize(width: mainCLV.bounds.width / 2 - 10, height: mainCLV.bounds.height / 2 - 10)
    }
}

extension ViewController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
       textField.resignFirstResponder()
       return true
    }
    
    public func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool{
        //input text
        let searchText  = textField.text! + string
        //add matching text to arrya
        fillerArray = self.listPlace.filter({(($0.location).localizedCaseInsensitiveContains(searchText))})
        self.mainCLV.reloadData();
        
        return true
    }
}
            
        
        
        
        



